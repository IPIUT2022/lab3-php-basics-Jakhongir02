<?php

$array = file("Task3doc.txt");

foreach($array as $arr){
    $ass_arr=explode(' ',$arr);
    $ass_arr2[$ass_arr[0]] = $ass_arr[1];
}

foreach($ass_arr2 as $x => $x_value) {
    echo "Key:" . $x . ", Value:" . $x_value;
    echo "<br>";
  }

?>